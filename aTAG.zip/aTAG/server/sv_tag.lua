ESX = nil

local function isWebhookSet(val)
    return val ~= nil and val ~= ""
end

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


TriggerEvent('esx_phone:registerNumber', 'tagjob', 'alerte tagjob', true, true)
TriggerEvent('esx_society:registerSociety', 'tagjob', 'tagjob', 'society_tagjob', 'society_tagjob', 'society_tagjob', {type = 'private'})


ESX.RegisterServerCallback('tagjob:getStockItems', function(source, cb)
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_tagjob', function(inventory)
		cb(inventory.items)
	end)
end)

RegisterNetEvent('tagjob:getStockItem')
AddEventHandler('tagjob:getStockItem', function(itemName, count)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_tagjob', function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		-- is there enough in the society?
		if count > 0 and inventoryItem.count >= count then
				inventory.removeItem(itemName, count)
				xPlayer.addInventoryItem(itemName, count)
				TriggerClientEvent('esx:showNotification', _source, 'Objet retiré', count, inventoryItem.label)
		else
			TriggerClientEvent('esx:showNotification', _source, "Quantité invalide")
		end
	end)
end)

ESX.RegisterServerCallback('tagjob:getPlayerInventory', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	local items   = xPlayer.inventory

	cb({items = items})
end)

RegisterNetEvent('tagjob:putStockItems')
AddEventHandler('tagjob:putStockItems', function(itemName, count)
	local xPlayer = ESX.GetPlayerFromId(source)
	local sourceItem = xPlayer.getInventoryItem(itemName)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_tagjob', function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		-- does the player have enough of the item?
		if sourceItem.count >= count and count > 0 then
			xPlayer.removeInventoryItem(itemName, count)
			inventory.addItem(itemName, count)
			xPlayer.showNotification(_U('have_deposited', count, inventoryItem.name))
		else
			TriggerClientEvent('esx:showNotification', _source, "Quantité invalide")
		end
	end)
end)

AddEventHandler('playerDropped', function()
	-- Save the source in case we lose it (which happens a lot)
	local _source = source

	-- Did the player ever join?
	if _source ~= nil then
		local xPlayer = ESX.GetPlayerFromId(_source)

		-- Is it worth telling all clients to refresh?
		if xPlayer ~= nil and xPlayer.job ~= nil and xPlayer.job.name == 'tagjob' then
			Citizen.Wait(5000)
			TriggerClientEvent('esx_tagjobjob:updateBlip', -1)
		end
	end
end)

RegisterServerEvent('esx_tagjobjob:spawned')
AddEventHandler('esx_tagjobjob:spawned', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	if xPlayer ~= nil and xPlayer.job ~= nil and xPlayer.job.name == 'tagjob' then
		Citizen.Wait(5000)
		TriggerClientEvent('esx_tagjobjob:updateBlip', -1)
	end
end)

AddEventHandler('onResourceStart', function(resource)
	if resource == GetCurrentResourceName() then
		Citizen.Wait(5000)
		TriggerClientEvent('esx_tagjobjob:updateBlip', -1)
	end
end)

AddEventHandler('onResourceStop', function(resource)
	if resource == GetCurrentResourceName() then
		TriggerEvent('esx_phone:removeNumber', 'tagjob')
	end
end)

RegisterServerEvent('esx_tagjobjob:message')
AddEventHandler('esx_tagjobjob:message', function(target, msg)
	TriggerClientEvent('esx:showNotification', target, msg)
end)

RegisterNetEvent('tagjob:frigo')
AddEventHandler('tagjob:frigo', function(ITEM,price)

    local _source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local xMoney = xPlayer.getMoney()

    if xMoney >= price then
        xPlayer.removeMoney(price)
        xPlayer.addInventoryItem(ITEM, 1)
        TriggerClientEvent('esx:showNotification', source, "~g~Achats~w~ effectué !")
    else
         TriggerClientEvent('esx:showNotification', source, "Vous n'avez assez ~r~d\'argent")
    end
end)

RegisterCommand('persotag', function(source, args, rawCommand)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    if xPlayer.job.name == "tagjob" then
        local src = source
        local msg = rawCommand:sub(10)
        local args = msg
        if player ~= false then
            local name = GetPlayerName(source)
            local xPlayers	= ESX.GetPlayers()
        for i=1, #xPlayers, 1 do
            local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
            TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], 'Anonyme', '~y~Annonce Anonyme', '~b~ '..msg..'', 'CHAR_BLOCKED', 0)
        end
    else
        TriggerClientEvent('esx:showAdvancedNotification', _source, 'Avertisement', '~r~Erreur' , '~y~Tu n\'es pas membre de cette entreprise pour faire cette commande', 'CHAR_BLOCKED', 0)
    end
else
    TriggerClientEvent('esx:showAdvancedNotification', _source, 'Avertisement', '~r~Erreur' , '~y~Tu n\'es pas membre de cette entreprise pour faire cette commande', 'CHAR_BLOCKED', 0)
end
end, false)

RegisterServerEvent('tagjob:prendreitems')
AddEventHandler('tagjob:prendreitems', function(itemName, count)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local sourceItem = xPlayer.getInventoryItem(itemName)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_tagjob', function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		-- is there enough in the society?
		if count > 0 and inventoryItem.count >= count then

			-- can the player carry the said amount of x item?
			if sourceItem.limit ~= -1 and (sourceItem.count + count) > sourceItem.limit then
				TriggerClientEvent('esx:showNotification', _source, "quantité invalide")
			else
				inventory.removeItem(itemName, count)
				xPlayer.addInventoryItem(itemName, count)
				TriggerClientEvent('esx:showNotification', _source, 'Objet retiré', count, inventoryItem.label)
			end
		else
			TriggerClientEvent('esx:showNotification', _source, "quantité invalide")
		end
	end)
end)


RegisterNetEvent('tagjob:stockitem')
AddEventHandler('tagjob:stockitem', function(itemName, count)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(source)
	local sourceItem = xPlayer.getInventoryItem(itemName)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_tagjob', function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		-- does the player have enough of the item?
		if sourceItem.count >= count and count > 0 then
			xPlayer.removeInventoryItem(itemName, count)
			inventory.addItem(itemName, count)
			TriggerClientEvent('esx:showNotification', _source, "Objet déposé "..count..""..inventoryItem.label.."")
		else
			TriggerClientEvent('esx:showNotification', _source, "quantité invalide")
		end
	end)
end)


ESX.RegisterServerCallback('tagjob:inventairejoueur', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	local items   = xPlayer.inventory

	cb({items = items})
end)

ESX.RegisterServerCallback('tagjob:prendreitem', function(source, cb)
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_tagjob', function(inventory)
		cb(inventory.items)
	end)
end)

ESX.RegisterServerCallback('tagjob:getArmoryWeapons', function(source, cb)
	TriggerEvent('esx_datastore:getSharedDataStore', 'society_tagjob', function(store)
		local weapons = store.get('weapons')

		if weapons == nil then
			weapons = {}
		end

		cb(weapons)
	end)
end)

ESX.RegisterServerCallback('tagjob:addArmoryWeapon', function(source, cb, weaponName, removeWeapon)
	local xPlayer = ESX.GetPlayerFromId(source)

	if removeWeapon then
		xPlayer.removeWeapon(weaponName)
	end

	TriggerEvent('esx_datastore:getSharedDataStore', 'society_tagjob', function(store)
		local weapons = store.get('weapons') or {}
		local foundWeapon = false

		for i=1, #weapons, 1 do
			if weapons[i].name == weaponName then
				weapons[i].count = weapons[i].count + 1
				foundWeapon = true
				break
			end
		end

		if not foundWeapon then
			table.insert(weapons, {
				name  = weaponName,
				count = 1
			})
		end

		store.set('weapons', weapons)
		cb()
	end)
end)

ESX.RegisterServerCallback('tagjob:removeArmoryWeapon', function(source, cb, weaponName)
	local xPlayer = ESX.GetPlayerFromId(source)
	xPlayer.addWeapon(weaponName, 500)

	TriggerEvent('esx_datastore:getSharedDataStore', 'society_tagjob', function(store)
		local weapons = store.get('weapons') or {}

		local foundWeapon = false

		for i=1, #weapons, 1 do
			if weapons[i].name == weaponName then
				weapons[i].count = (weapons[i].count > 0 and weapons[i].count - 1 or 0)
				foundWeapon = true
				break
			end
		end

		if not foundWeapon then
			table.insert(weapons, {
				name = weaponName,
				count = 0
			})
		end

		store.set('weapons', weapons)
		cb()
	end)
end)


local commande = {}

ESX.RegisterServerCallback('aTagJob:infocommande', function(source, cb)
    cb(commande)
end)

RegisterServerEvent("aTagJob:nouvellecommande")
AddEventHandler("aTagJob:nouvellecommande", function()
    local xPlayers    = ESX.GetPlayers()
    for i=1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        if xPlayer.job.name == 'tagjob' then
            TriggerClientEvent("aTagJob:envoielanotif", xPlayers[i])
        end
end
end)

RegisterServerEvent("aTagJob:closecommande")
AddEventHandler("aTagJob:closecommande", function(nom, raison)
    table.remove(commande, id, nom, args, detaillecommande)
end)


RegisterServerEvent("aTagJob:addcommande")
AddEventHandler("aTagJob:addcommande", function(lacommande, lenumero, lenom)
	local xPlayer = ESX.GetPlayerFromId(source)
    local NomDuMec = xPlayer.getName()
    local idDuMec = source
	local contratlog = lacommande
	local numsclient = lenumero
	local nomclient = lenom
    table.insert(commande, {
        nom = NomDuMec,
		id = idDuMec,
        args = "Contrat T.A.G",
        detaillecommande = lacommande
    })

	print(contratlog)
	TriggerClientEvent('esx:showAdvancedNotification', source, 'T.A.G', '~r~Contrat', 'Votre demande de contrat a bien été envoyer!', 'CHAR_ARTHUR', 2)
	TriggerEvent('aTagJob:nouvellecommande')
	if isWebhookSet(tagjob.webhook.onContratTag) then
		sendWebhook(("Une personne (Pseudo en cas de troll : %s ) a fait une demande de contrat : \n\n __%s__ "):format(GetPlayerName(source), ("Identité : "..nomclient.."\n Numéros : "..numsclient.."\n Description : "..contratlog)), "orange", tagjob.webhook.onContratTag)
	end
end)


local webhookColors = {
    ["red"] = 16711680,
    ["green"] = 56108,
    ["grey"] = 8421504,
    ["orange"] = 16744192
}

function sendWebhook(message,color,url)
    local DiscordWebHook = url
    local embeds = {
        {
            ["title"]= message,
            ["type"]="rich",
            ["color"] = webhookColors[color],
            ["footer"]=  {
                ["text"]= "Contrat T.A.G",
            },
        }
    }
    PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({ username = "Contrat T.A.G",embeds = embeds}), { ['Content-Type'] = 'application/json' })
end

local okpaiement = true

RegisterServerEvent('findemission')
AddEventHandler('findemission', function()
	if okpaiement == false then
		okpaiement = true
	else
	end
end)

RegisterServerEvent('debutdemission')
AddEventHandler('debutdemission', function()
	if okpaiement == true then
		okpaiement = false
	else
	end
end)

RegisterServerEvent('donnetoncheque')
AddEventHandler('donnetoncheque', function()
	if okpaiement == false then
		ChequeOk()
	else
	end
end)

function ChequeOk()
	local prix = math.random(500, 1000)
    local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.addAccountMoney("black_money", prix)
	TriggerClientEvent('esx:showAdvancedNotification', source, '~g~Fleeca Bank', '~b~Virement~s~', 'Un virement d\'un montant de ~g~'..prix..'$ ~w~vien d\'etre effectuer sur votre compte ~r~offshore', 'CHAR_BANK_FLEECA', 2)
end

RegisterServerEvent('donnemediumcheque')
AddEventHandler('donnemediumcheque', function()
	if okpaiement == false then
		ChequeMeduimOk()
	else
	end
end)

function ChequeMeduimOk()
	local prix = math.random(1500, 3500)
    local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.addAccountMoney("black_money", prix)
	TriggerClientEvent('esx:showAdvancedNotification', source, '~g~Fleeca Bank', '~b~Virement~s~', 'Un virement d\'un montant de ~g~'..prix..'$ ~w~vien d\'etre effectuer sur votre compte ~r~offshore', 'CHAR_BANK_FLEECA', 2)
end

RegisterServerEvent('donnehardcheque')
AddEventHandler('donnehardcheque', function()
	if okpaiement == false then
		ChequeHardOk()
	else
	end
end)

function ChequeHardOk()
	local prix = math.random(4000, 6500)
    local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.addAccountMoney("black_money", prix)
	TriggerClientEvent('esx:showAdvancedNotification', source, '~g~Fleeca Bank', '~b~Virement~s~', 'Un virement d\'un montant de ~g~'..prix..'$ ~w~vien d\'etre effectuer sur votre compte ~r~offshore', 'CHAR_BANK_FLEECA', 2)
end