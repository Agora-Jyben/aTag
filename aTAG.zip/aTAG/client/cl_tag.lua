ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local PlayerData = {}

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

RegisterNetEvent('esx:setJob2')
AddEventHandler('esx:setJob2', function(job2)
    ESX.PlayerData.job2 = job2
end)

function defESX()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Wait(0)
    end
end

Citizen.CreateThread(function()
    defESX()
end)


local index = {
    items = 1
}

local percent = 100
local a = 255
local nombre = {}

local max = 10
Numbers = {}

Citizen.CreateThread(function()
    for i = 1, max do
        table.insert(Numbers, i)
    end
end)

local lescommande = {}

local function getInfoReport()
    local info = {}
    ESX.TriggerServerCallback('aTagJob:infocommande', function(info)
        lescommande = info
    end)
end

Citizen.CreateThread(function()
    if tagjob.jeveuxblips then
    local tagjobmap = AddBlipForCoord(tagjob.pos.blips.position.x, tagjob.pos.blips.position.y, tagjob.pos.blips.position.z)

    SetBlipSprite(tagjobmap, 362)
    SetBlipColour(tagjobmap, 76)
    SetBlipScale(tagjobmap, 0.65)
    SetBlipAsShortRange(tagjobmap, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString("T.A.G")
    EndTextCommandSetBlipName(tagjobmap)
end
end)

--------------------------------------------------------
function ContratTagJob()
    local contratjobtag = RageUI.CreateMenu(nil, "", 10,222, "plainte", "contrat")
  
    RageUI.Visible(contratjobtag, not RageUI.Visible(contratjobtag))
  
    while contratjobtag do
        Citizen.Wait(0)
        RageUI.IsVisible(contratjobtag, true, false, true, function()
            RageUI.Separator("")
            RageUI.Separator("~y~↓ ~s~Votre Contrat ~y~↓")
   
            RageUI.ButtonWithStyle("Demande de Contrat", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                if (Selected) then
                    local lenumero = KeyboardInput("Votre numéro de télèphone !", '' , 100)
                    local lenom = KeyboardInput("Votre Nom et Prénom !", '' , 100)
                    local contrat = KeyboardInput("Demande de rendez-vous pour un contrat !", '' , 100)
                    TriggerServerEvent('aTagJob:addcommande', contrat, lenumero, lenom)
                end
            end)

        end, function() 
        end)
  
        if not RageUI.Visible(contratjobtag) then
            contratjobtag = RMenu:DeleteType("contratjobtag", true)
        end
    end
end

Citizen.CreateThread(function()
    while true do
        local Timer = 500

        local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
        local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, tagjob.pos.contratTag.position.x, tagjob.pos.contratTag.position.y, tagjob.pos.contratTag.position.z)
        if dist3 <= 10.0 and tagjob.jeveuxmarkercontratTag then
            Timer = 0
            DrawMarker(20, tagjob.pos.contratTag.position.x, tagjob.pos.contratTag.position.y, tagjob.pos.contratTag.position.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
            end
            if dist3 <= 3.0 then
            Timer = 0   
                RageUI.Text({ message = "Appuyez sur ~r~[E]~s~ pour un contrat avec le T.A.G", time_display = 1 })
                if IsControlJustPressed(1,51) then           
                    ContratTagJob()
                end   
            end
    Citizen.Wait(Timer)
 end
end)

local commandesR = {}
local pospedmiss = {}
posone = nil
local ped = {}
local pedkiler = {}
local pedkiler2 = {}
local pedkiler3 = {}
local pedkiler4 = {}
local pospedchoisi = nil
local stopped = nil
local missiontagrecup = false
local missionlancer = false
local testefunction1, testefunction2, testefunction3, testefunction4 = false, false, false, false
local selectItems
local CustomerIsEnteringVehicle = false
local posfinalchoisi = math.random(1, 6)
local affichehelp = false
local affichepoint = false
local affichepointfinal = false
local pedmissBlip
local finalBlip


--------------------------------------------------------------------
function Menuf6TagJob()
    local TagJobf6 = RageUI.CreateMenu(nil, "", 10,222, "plainte", "interaction_bgd")
    local TagJobf6commandes = RageUI.CreateSubMenu(TagJobf6, nil, "", 10,222, "plainte", "contrat")
    local TagJobf6info = RageUI.CreateSubMenu(TagJobf6commandes, nil, "", 10,222, "plainte", "contrat")
    local TagJoboperation = RageUI.CreateSubMenu(TagJobf6, nil, "", 10,222, "plainte", "interaction_bgd")
    getInfoReport()
    defESX()
    RageUI.Visible(TagJobf6, not RageUI.Visible(TagJobf6))
    while TagJobf6 do
        Citizen.Wait(0)
            RageUI.IsVisible(TagJobf6, true, false, true, function()
                RageUI.Separator("")

                RageUI.Separator("~y~↓ ~s~Facture ~y~↓")

                RageUI.ButtonWithStyle("Facture",nil, {RightLabel = "→"}, true, function(_,_,s)
                    local player, distance = ESX.Game.GetClosestPlayer()
                    if s then
                        local raison = ""
                        local montant = 0
                        AddTextEntry("FMMC_MPM_NA", "Objet de la facture")
                        DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Donnez le motif de la facture :", "", "", "", "", 30)
                        while (UpdateOnscreenKeyboard() == 0) do
                            DisableAllControlActions(0)
                            Wait(0)
                        end
                        if (GetOnscreenKeyboardResult()) then
                            local result = GetOnscreenKeyboardResult()
                            if result then
                                raison = result
                                result = nil
                                AddTextEntry("FMMC_MPM_NA", "Montant de la facture")
                                DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Indiquez le montant de la facture :", "", "", "", "", 30)
                                while (UpdateOnscreenKeyboard() == 0) do
                                    DisableAllControlActions(0)
                                    Wait(0)
                                end
                                if (GetOnscreenKeyboardResult()) then
                                    result = GetOnscreenKeyboardResult()
                                    if result then
                                        montant = result
                                        result = nil
                                        if player ~= -1 and distance <= 3.0 then
                                            TriggerServerEvent('esx_billing:sendBill', GetPlayerServerId(player), 'society_tagjob', ('T.A.G'), montant)
                                            TriggerEvent('esx:showAdvancedNotification', 'Fl~g~ee~s~ca ~g~Bank', 'Facture envoyée : ', 'Vous avez envoyé une facture d\'un montant de : ~g~'..montant.. '$ ~s~pour cette raison : ~b~' ..raison.. '', 'CHAR_BANK_FLEECA', 9)
                                        else
                                            ESX.ShowNotification("~r~Probleme~s~: Aucuns joueurs proche")
                                        end
                                    end
                                end
                            end
                        end
                    end
                end)


                RageUI.Separator("~y~↓ ~s~Annonce ~y~↓")


                RageUI.ButtonWithStyle("Annonces anonyme",nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected)
                    if (Selected) then 
                        local annoncetag = AnnonceTagJob("Message", "", 100)
						ExecuteCommand("persotag "..annoncetag)
					end 
                end)

                RageUI.Separator("~y~↓ ~s~Contrats ~y~↓")

                RageUI.ButtonWithStyle("Liste des contrats", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                end, TagJobf6commandes)

                RageUI.Separator("~y~↓ ~s~Mission ~y~↓")

                RageUI.ButtonWithStyle("Mission Job", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                end, TagJoboperation)

                end, function() 
                end)

                RageUI.IsVisible(TagJobf6commandes, true, false, true, function()
                    if #lescommande >= 1 then
                        RageUI.Separator("")
                        RageUI.Separator("~y~↓ ~s~Nouveau contrat ~y~↓")

                        for k,v in pairs(lescommande) do
                            RageUI.ButtonWithStyle(k.." - Client [~y~"..v.nom.."~s~]", nil, {RightLabel = "→→"},true , function(_,_,s)
                                if s then
                                    nom = v.nom
                                    id = v.id
                                    nbreport = k
                                    raison = v.args
                                    lacommande = v.detaillecommande
                                end
                            end, TagJobf6info)
                        end
                    else
                        RageUI.Separator("")
                        RageUI.Separator("")
                        RageUI.Separator("~y~Aucun contrat~s~")
                        RageUI.Separator("")
                    end
                    
                end, function() 
                end)

                RageUI.IsVisible(TagJoboperation, true, false, true, function()
                    RageUI.Separator("")
                    RageUI.Separator("~y~↓ ~s~Mission Protection T.A.G ~y~↓")

                    RageUI.ButtonWithStyle("Executer un contrat de protection aléatoire", nil, {RightLabel = "→→"}, true, function(_,_,s)
                        if s then
                            if missiontagrecup == false then
                                missiontagrecup = true
                                stopped = false
                                missionlancer = true
                                StartMissionTAG()
                            end
                        end
                    end)

                    RageUI.ButtonWithStyle("Stopper l'execution du contrat aléatoire", nil, {RightLabel = "→→"}, true, function(_,_,s)
                        if s then
                            MissionTagTerminerDemander()
                            missionlancer = false
                        end
                    end)
                    
                end, function() 
                end)

                RageUI.IsVisible(TagJobf6info, true, false, true, function()
                    RageUI.Separator("")

                    RageUI.Separator("Contrat numéro : ~y~"..nbreport)
                    RageUI.Separator("Client : ~y~"..nom)
                    RageUI.Separator("Details du contrat : ~y~"..raison)

                    RageUI.Separator("~y~↓ ~s~Détaille de la demande ~y~↓")

                    RageUI.ButtonWithStyle(lacommande, nil, {RightLabel = nil}, true, function(_,_,s)
                        if s then
                        end
                    end)
                    
                    RageUI.ButtonWithStyle("~r~Confirmer la fin de contrat", "~r~Suppression du contrat....!", {RightLabel = "→→"}, true, function(_,_,s)
                        if s then
                            TriggerServerEvent('aTagJob:closecommande',nom, raison)
                        end
                    end)

                end, function() 
                end)

                if not RageUI.Visible(TagJobf6) and not RageUI.Visible(TagJobf6commandes) and not RageUI.Visible(TagJobf6info) and not RageUI.Visible(TagJoboperation) then
                    TagJobf6 = RMenu:DeleteType("TagJobf6", true)
        end
    end
end

function StartMissionTAG()
    selectItems = math.random(1, 3)
	print("Mission lancer")
    local playerPed = PlayerPedId()
	local pospedchoisi = math.random(1, 4)
	local pospedmiss = GetEntityCoords(pedmiss)
	posone = vector3(tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z)
	
	pedmiss = tagjob.pedMissionC[math.random(1, #tagjob.pedMissionC)]
	pedmiss = string.upper(pedmiss)
	RequestModel(GetHashKey(pedmiss))
	while not HasModelLoaded(GetHashKey(pedmiss)) or not HasCollisionForModelLoaded(GetHashKey(pedmiss)) do
		Wait(1)
	end

	if pedmiss then
		Citizen.CreateThread(function()
			while not HasModelLoaded(pedmiss) do
				RequestModel(pedmiss)
				Wait(20)
			end

            TriggerServerEvent("debutdemission")

			if pospedchoisi > 0 or pospedchoisi <= 6 then

				ped = CreatePed("PED_TYPE_CIVFEMALE", pedmiss, tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z, false, true)
				
				SetBlockingOfNonTemporaryEvents(ped, true)
				FreezeEntityPosition(ped, true)
				SetEntityInvincible(ped, true)
				
				print(posone)

			end

            local lib, anim = 'anim@heists@ornate_bank@hostages@cashier_b@', 'flinch_outro' 
				
				Wait(5)
				Citizen.CreateThread(function()
					ESX.Streaming.RequestAnimDict(lib, function()
					TaskPlayAnim(ped, lib, anim, 8.0, -8.0, -1, 1, 0, false, false, false)

					Citizen.Wait(100)
					while IsEntityPlayingAnim(ped, lib, anim, 3) do
						Citizen.Wait(0)
					end
					end)
				end)

			if selectItems > 0 or selectItems <= 3 then
				RageUI.Popup{
					message = "~w~[~y~Client~w~]\nBonjour je vous contact pour une : ~g~"..tagjob.styleMission[selectItems].label.." ~w~ ."
				}
				
				commandesR = tagjob.styleMission[selectItems].item

				print("Item selectionner : "..commandesR)

				if ped ~= nil then
					pedmissBlip = AddBlipForEntity(ped)

					SetBlipAsFriendly(pedmissBlip, true)
					SetBlipColour(pedmissBlip, 6)
					SetBlipCategory(pedmissBlip, 3)
					SetBlipRoute(pedmissBlip, true)

					SetEntityAsMissionEntity(ped, true, false)
					ClearPedTasksImmediately(ped)
					SetBlockingOfNonTemporaryEvents(ped, true)
				end

				local street = GetStreetNameAtCoord(posone.x, posone.y, posone.x)
				local msg    = nil

				print(street)

				if street ~= 0 then
					msg = string.format('~s~L\'adresse du client ce trouve à~y~ %s', GetStreetNameFromHashKey(street))
				else
					msg = string.format('~s~L\'adresse du client ce trouve à~y~ %s', GetStreetNameFromHashKey(street))
				end

				ESX.ShowNotification(msg)


                pedkiller = tagjob.pedTAGMission[math.random(1, #tagjob.pedTAGMission)]
                pedkiller = string.upper(pedkiller)
                RequestModel(GetHashKey(pedkiller))
                while not HasModelLoaded(GetHashKey(pedkiller)) or not HasCollisionForModelLoaded(GetHashKey(pedkiller)) do
                    Wait(1)
                end

                if pedkiller then

                    while not HasModelLoaded(pedkiller) do
                        RequestModel(pedkiller)
                        Wait(20)
                    end
        
                    Citizen.CreateThread(function()
                        while missionlancer do
                            Citizen.Wait(1)
                            if pospedchoisi > 0 or pospedchoisi <= 6 then
                                if selectItems == 1 then
                                    local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                                    local distkiller = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z+1 )
                                    if distkiller < 45 then
                                        if stopped == false then
                                            stopped = true
                                            pedkiler = CreatePed("PED_TYPE_CIVFEMALE", pedkiller, tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y+5, tagjob.pMission[pospedchoisi].z, false, true)
                                                SetEntityAsMissionEntity(pedkiler, false, false)
                                                FreezeEntityPosition(pedkiler, false)
                                                TaskCombatPed(pedkiler, playerPed, 0, 16)
                                                SetPedAsGroupMember(pedkiler, groupkiller)
                                            pedkiler2 = CreatePed("PED_TYPE_CIVFEMALE", pedkiller2, tagjob.pMission[pospedchoisi].x+5, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z, false, true)
                                                SetEntityAsMissionEntity(pedkiler2, false, false)
                                                FreezeEntityPosition(pedkiler2, false)
                                                TaskCombatPed(pedkiler2, playerPed, 0, 16)
                                                SetPedAsGroupMember(pedkiler2, groupkiller)
                                                testefunction1 = true
                                        else
                                        end
                                    end
                                elseif selectItems == 2 then
                                    local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                                    local distkiller = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z+1 )
                                    if distkiller < 45 then
                                        if stopped == false then
                                            stopped = true
                                            pedkiler = CreatePed("PED_TYPE_CIVFEMALE", pedkiller, tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y+5, tagjob.pMission[pospedchoisi].z, false, true)
                                                SetEntityAsMissionEntity(pedkiler, false, false)
                                                FreezeEntityPosition(pedkiler, false)
                                                TaskCombatPed(pedkiler, playerPed, 0, 16)
                                                GiveWeaponToPed(pedkiler, 0x5EF9FEC4, 0, true, true)
                                                SetPedAsGroupMember(pedkiler, groupkiller)
                                            pedkiler2 = CreatePed("PED_TYPE_CIVFEMALE", pedkiller, tagjob.pMission[pospedchoisi].x+5, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z, false, true)
                                                SetEntityAsMissionEntity(pedkiler2, false, false)
                                                FreezeEntityPosition(pedkiler2, false)
                                                TaskCombatPed(pedkiler2, playerPed, 0, 16)
                                                GiveWeaponToPed(pedkiler2, 0x958A4A8F, 0, true, true)
                                                SetPedAsGroupMember(pedkiler2, groupkiller)
                                            pedkiler3 = CreatePed("PED_TYPE_CIVFEMALE", pedkiller, tagjob.pMission[pospedchoisi].x+10, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z, false, true)
                                                SetEntityAsMissionEntity(pedkiler3, false, false)
                                                FreezeEntityPosition(pedkiler3, false)
                                                TaskCombatPed(pedkiler3, playerPed, 0, 16)
                                                GiveWeaponToPed(pedkiler3, 0x958A4A8F, 0, true, true)
                                                SetPedAsGroupMember(pedkiler3, groupkiller)
                                                testefunction2 = true
                                        else
                                        end
                                    end
                                elseif selectItems == 3 then
                                    local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                                    local distkiller = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z+1 )
                                    if distkiller < 45 then
                                        if stopped == false then
                                            stopped = true
                                            pedkiler = CreatePed("PED_TYPE_CIVFEMALE", pedkiller, tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y+5, tagjob.pMission[pospedchoisi].z, false, true)
                                                SetEntityAsMissionEntity(pedkiler, false, false)
                                                FreezeEntityPosition(pedkiler, false)
                                                TaskCombatPed(pedkiler, playerPed, 0, 16)
                                                GiveWeaponToPed(pedkiler, 0xC1B3C3D1, 0, true, true)
                                                SetPedAsGroupMember(pedkiler, groupkiller)
                                            pedkiler2 = CreatePed("PED_TYPE_CIVFEMALE", pedkiller, tagjob.pMission[pospedchoisi].x+5, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z, false, true)   
                                                SetEntityAsMissionEntity(pedkiler2, false, false) 
                                                FreezeEntityPosition(pedkiler2, false)
                                                TaskCombatPed(pedkiler2, playerPed, 0, 16)
                                                GiveWeaponToPed(pedkiler2, 0xEF951FBB, 0, true, true)
                                                SetPedAsGroupMember(pedkiler2, groupkiller)
                                            pedkiler3 = CreatePed("PED_TYPE_CIVFEMALE", pedkiller, tagjob.pMission[pospedchoisi].x+10, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z, false, true)
                                                SetEntityAsMissionEntity(pedkiler3, false, false)
                                                FreezeEntityPosition(pedkiler3, false)
                                                TaskCombatPed(pedkiler3, playerPed, 0, 16)
                                                GiveWeaponToPed(pedkiler3, 0xEF951FBB, 0, true, true)
                                                SetPedAsGroupMember(pedkiler3, groupkiller)
                                            pedkiler4 = CreatePed("PED_TYPE_CIVFEMALE", pedkiller, tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y+10, tagjob.pMission[pospedchoisi].z, false, true)
                                                SetEntityAsMissionEntity(pedkiler4, false, false)
                                                FreezeEntityPosition(pedkiler4, false)
                                                TaskCombatPed(pedkiler4, playerPed, 0, 16)
                                                GiveWeaponToPed(pedkiler4, 0xBFEFFF6D, 0, true, true)
                                                SetPedAsGroupMember(pedkiler4, groupkiller)
                                                testefunction3 = true
                                        else
                                        end
                                    end
                                end
                            end
                        end
                    end)
                end


				Citizen.CreateThread(function()
					while missionlancer do
						Citizen.Wait(1)

						local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
						local distmiss = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, tagjob.pMission[pospedchoisi].x, tagjob.pMission[pospedchoisi].y, tagjob.pMission[pospedchoisi].z+1 )
                        
						if distmiss < 3 then

                            if missionlancer == true then

                                ESX.ShowHelpNotification("~INPUT_TALK~ pour interagir avec la personne")

                                if IsControlJustPressed(1,51) then
                                    RemoveBlip(pedmissBlip)

                                    SetEntityAsMissionEntity(ped, false, false)
                                    ClearPedTasksImmediately(ped)
                                    SetBlockingOfNonTemporaryEvents(ped, false)
                                    FreezeEntityPosition(ped, false)
                                    SetEntityInvincible(ped, false)

                                    RageUI.Popup{
                                        message = "~r~[~b~ Inconnue ~r~]\n Merci beaucoup, vous m'avez sauvé la vie !"
                                    }

                                    Wait(1500)

                                    local vehicle = GetVehiclePedIsIn(playerPed, false)
                                    
                                    if not IsPedInAnyVehicle(playerPed, false) then
                                        RageUI.Popup{
                                            message = "~r~[~b~ Inconnue ~r~]\n Il nous faudrais une voiture !"
                                        }
                                    elseif IsPedInAnyVehicle(playerPed, false) then
                                        
                                        RageUI.Popup{
                                            message = "~r~[~b~ Inconnue ~r~]\n J'effectue le virement des que l'ont sera arriver chez moi !"
                                        }
        
                                        local vehicle = GetVehiclePedIsIn(playerPed, false)
                                        posfinalmision = vector3(tagjob.posMissionFinal[posfinalchoisi].x, tagjob.posMissionFinal[posfinalchoisi].y, tagjob.posMissionFinal[posfinalchoisi].z)
            
                                        finalBlip = AddBlipForCoord(vector3(posfinalmision))
                        
                                        SetBlipAsFriendly(finalBlip, true)
                                        SetBlipRouteColour(finalBlip --[[ Blip ]], 6 --[[ integer ]])

                                        TaskEnterVehicle(ped, vehicle, -1, 2, 2.0, 0)
                                        affichehelp = true
                                    end
                                end
                            end
                        end
                    end
                end)

                Citizen.CreateThread(function()
					while missionlancer do
						Citizen.Wait(1)

						local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                        local distmissfinal = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, tagjob.posMissionFinal[posfinalchoisi].x, tagjob.posMissionFinal[posfinalchoisi].y, tagjob.posMissionFinal[posfinalchoisi].z+1 )

                            if IsPedInAnyVehicle(ped, false) then
                                if distmissfinal < 5 --[[and affichepoint == true]] then
                                    
                                    ESX.ShowHelpNotification("~INPUT_TALK~ pour laisser la personne ici")
                                    if IsControlJustPressed(1,51) then

                                        RemoveBlip(finalBlip)

                                        RageUI.Popup{
                                            message = "~r~[~b~ Inconnue ~r~]\n Merci beaucoup je vous dois la vie !"
                                        }

                                        Wait(2000)

                                        RageUI.Popup{
                                            message = "~r~[~b~ Inconnue ~r~]\n Tenez comme promis, voici votre virement !"
                                        }

                                        TaskLeaveVehicle(ped, vehicle, 0)
                                        SetEntityAsMissionEntity(ped, false, false)
                                        ClearPedTasksImmediately(ped)
                                        SetBlockingOfNonTemporaryEvents(ped, false)
                                        FreezeEntityPosition(ped, false)
                                        SetEntityInvincible(ped, false)
                                        
                                        if selectItems == 1 then
                                            TriggerServerEvent("donnetoncheque")
                                            TriggerServerEvent("findemission")
                                            SetTimeout(10000, function()
                                                MissionTagEasyTerminer()
                                                affichepoint = false
                                                affichehelp = false
                                            end)
                                        elseif selectItems == 2 then
                                            TriggerServerEvent("donnemediumcheque")
                                            TriggerServerEvent("findemission")
                                            SetTimeout(10000, function()
                                                MissionTagMediumTerminer()
                                                affichepoint = false
                                                affichehelp = false
                                            end)
                                        elseif selectItems == 3 then
                                            TriggerServerEvent("donnehardcheque")
                                            TriggerServerEvent("findemission")
                                            SetTimeout(10000, function()
                                                MissionTagHardTerminer()
                                                affichepoint = false
                                                affichehelp = false
                                            end)
                                        end
                                    end
                                end
                            else
                            end
					end
				end)
			end
		end)
	end
end

function MissionTagEasyTerminer()
	DeleteEntity(ped)
    DeleteEntity(pedkiler)
    DeleteEntity(pedkiler2)
    RemoveBlip(finalBlip)

    if missiontagrecup == true then
        missiontagrecup = false
    end
    testefunction1 = false
    stopped = true

    missionlancer = false

    commandesR = {}
    pospedmiss = {}
    posone = nil
    pospedchoisi = nil
    selectItems = {}
end

function MissionTagMediumTerminer()
	DeleteEntity(ped)
    DeleteEntity(pedkiler)
    DeleteEntity(pedkiler2)
    DeleteEntity(pedkiler3)
    RemoveBlip(finalBlip)

    if missiontagrecup == true then
        missiontagrecup = false
    end
    testefunction2 = false
    stopped = true

    missionlancer = false

    commandesR = {}
    pospedmiss = {}
    posone = nil
    pospedchoisi = nil
    selectItems = {}
end

function MissionTagHardTerminer()
	DeleteEntity(ped)
    DeleteEntity(pedkiler)
    DeleteEntity(pedkiler2)
    DeleteEntity(pedkiler3)
    DeleteEntity(pedkiler4)
    RemoveBlip(finalBlip)

    if missiontagrecup == true then
        missiontagrecup = false
    end
    testefunction3 = false
    stopped = true

    missionlancer = false

    commandesR = {}
    pospedmiss = {}
    posone = nil
    pospedchoisi = nil
    selectItems = {}
end

function MissionTagTerminerDemander()
	DeleteEntity(ped)
    if testefunction1 == true then
        DeleteEntity(pedkiler)
        DeleteEntity(pedkiler2)
        if pedmissBlip then
            RemoveBlip(pedmissBlip)
        end
        if finalBlip then
            RemoveBlip(finalBlip)
        end
        testefunction1 = false

        missionlancer = false

        commandesR = {}
        pospedmiss = {}
        posone = nil
        pospedchoisi = nil
        selectItems = {}
    elseif testefunction2 == true then
        DeleteEntity(pedkiler)
        DeleteEntity(pedkiler2)
        DeleteEntity(pedkiler3)
        if pedmissBlip then
            RemoveBlip(pedmissBlip)
        end
        if finalBlip then
            RemoveBlip(finalBlip)
        end
        testefunction2 = false

        missionlancer = false

        commandesR = {}
        pospedmiss = {}
        posone = nil
        pospedchoisi = nil
        selectItems = {}
    elseif testefunction3 == true then 
        DeleteEntity(pedkiler)
        DeleteEntity(pedkiler2)
        DeleteEntity(pedkiler3)
        DeleteEntity(pedkiler4)
        if pedmissBlip then
            RemoveBlip(pedmissBlip)
        end
        if finalBlip then
            RemoveBlip(finalBlip)
        end
        testefunction3 = false

        missionlancer = false

        commandesR = {}
        pospedmiss = {}
        posone = nil
        pospedchoisi = nil
        selectItems = {}

    else
    end

    if missiontagrecup == true then
        missiontagrecup = false
    end

    stopped = true
    commandesR = {}
    pospedmiss = {}
    posone = nil
    pospedchoisi = nil
    selectItems = {}
end


function AnnonceTagJob(TextEntry, ExampleText, MaxStringLenght)


    AddTextEntry('FMMC_KEY_TIP1', TextEntry) 
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, " ", "", "", MaxStringLenght)
    blockinput = true

    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Citizen.Wait(0)
    end
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult() 
        Citizen.Wait(500) 
        blockinput = false
        return result 
    else
        Citizen.Wait(500) 
        blockinput = false 
        return nil 
    end
end

Keys.Register('F6', 'T.A.G', 'Ouvrir le menu Tueur à Gage', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'tagjob' or ESX.PlayerData.job2 and ESX.PlayerData.job2.name == 'tagjob' then
    	Menuf6TagJob()
	end
end)




function CoffreTagJob()
    local CTagJob = RageUI.CreateMenu("Coffre", "~p~T.A.G")
    CTagJob:SetRectangleBanner(0, 155, 0)
        RageUI.Visible(CTagJob, not RageUI.Visible(CTagJob))
            while CTagJob do
            Citizen.Wait(0)
            RageUI.IsVisible(CTagJob, true, true, true, function()

                RageUI.Separator("~y~↓ ~s~Objet ~y~↓")

                    RageUI.ButtonWithStyle("Retirer",nil, {RightLabel = ""}, true, function(Hovered, Active, Selected)
                        if Selected then
                            VRetirerobjet()
                            RageUI.CloseAll()
                        end
                    end)
                    
                    RageUI.ButtonWithStyle("Déposer",nil, {RightLabel = ""}, true, function(Hovered, Active, Selected)
                        if Selected then
                            VDeposerobjet()
                            RageUI.CloseAll()
                        end
                    end)

                    RageUI.Separator("~y~↓ ~s~Vêtements ~y~↓")

                    RageUI.ButtonWithStyle("Uniforme",nil, {RightLabel = ""}, true, function(Hovered, Active, Selected)
                        if Selected then
                            tenueTagJob()
                            RageUI.CloseAll()
                        end
                    end)

                    RageUI.ButtonWithStyle("Remettre sa tenue civil",nil, {RightLabel = ""}, true, function(Hovered, Active, Selected)
                        if (Selected) then   
                            ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
                                local isMale = skin.sex == 0
                                local isFemme = skin.sex == 1
            
                                if isMale then
                                    TriggerEvent('skinchanger:loadDefaultModel', isMale, function()
                                        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                                            TriggerEvent('skinchanger:loadSkin', skin)
                                            TriggerEvent('esx:restoreLoadout')
                                        end)
                                    end)
                                elseif isFemme then
                                    TriggerEvent('skinchanger:loadDefaultModel', isFemme, function()
                                        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                                            TriggerEvent('skinchanger:loadSkin', skin)
                                            TriggerEvent('esx:restoreLoadout')
                                        end)
                                    end)
                                end
                            end)
                        end
                    end)

                end, function()
                end)
            if not RageUI.Visible(CTagJob) then
            CTagJob = RMenu:DeleteType("CTagJob", true)
        end
    end
end

Citizen.CreateThread(function()
        while true do
            local Timer = 500
            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'tagjob' or ESX.PlayerData.job2 and ESX.PlayerData.job2.name == 'tagjob' then
            local plycrdjob = GetEntityCoords(GetPlayerPed(-1), false)
            local jobdist = Vdist(plycrdjob.x, plycrdjob.y, plycrdjob.z, tagjob.pos.coffre.position.x, tagjob.pos.coffre.position.y, tagjob.pos.coffre.position.z)
            if jobdist <= 10.0 and tagjob.jeveuxmarker then
                Timer = 0
                DrawMarker(20, tagjob.pos.coffre.position.x, tagjob.pos.coffre.position.y, tagjob.pos.coffre.position.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
                end
                if jobdist <= 1.0 then
                    Timer = 0
                        RageUI.Text({ message = "Appuyez sur ~r~[E]~s~ pour accéder au coffre", time_display = 1 })
                        if IsControlJustPressed(1,51) then
                        CoffreTagJob()
                    end   
                end
            end 
        Citizen.Wait(Timer)   
    end
end)


function GarageTagJob()
    local GTagJob = RageUI.CreateMenu("Garage", "~p~T.A.G")
    GTagJob:SetRectangleBanner(0, 0, 155)
      RageUI.Visible(GTagJob, not RageUI.Visible(GTagJob))
          while GTagJob do
              Citizen.Wait(0)
                  RageUI.IsVisible(GTagJob, true, true, true, function()
                      RageUI.ButtonWithStyle("Ranger la voiture", nil, {RightLabel = "→"},true, function(Hovered, Active, Selected)
                          if (Selected) then   
                          local veh,dist4 = ESX.Game.GetClosestVehicle(playerCoords)
                          if dist4 < 4 then
                              DeleteEntity(veh)
                              RageUI.CloseAll()
                              end 
                          end
                      end) 
  
                      for k,v in pairs(tagjob.GTagJobvoiture) do
                      RageUI.ButtonWithStyle(v.nom, nil, {RightLabel = "→"},true, function(Hovered, Active, Selected)
                          if (Selected) then
                          Citizen.Wait(1)  
                              spawnCarTagJob(v.modele)
                              RageUI.CloseAll()
                              end
                          end)
                      end
                  end, function()
                  end)
              if not RageUI.Visible(GTagJob) then
              GTagJob = RMenu:DeleteType("Garage", true)
          end
      end
  end
Citizen.CreateThread(function()
    while true do
            local Timer = 500
            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'tagjob' or ESX.PlayerData.job2 and ESX.PlayerData.job2.name == 'tagjob' then
              local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
              local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, tagjob.pos.garage.position.x, tagjob.pos.garage.position.y, tagjob.pos.garage.position.z)
                if dist3 <= 10.0 and tagjob.jeveuxmarker then
                  Timer = 0
                  DrawMarker(20, tagjob.pos.garage.position.x, tagjob.pos.garage.position.y, tagjob.pos.garage.position.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
                end
                if dist3 <= 3.0 then
                  Timer = 0   
                    RageUI.Text({ message = "Appuyez sur ~r~[E]~s~ pour accéder au garage", time_display = 1 })
                    if IsControlJustPressed(1,51) then           
                        GarageTagJob()
                    end   
                end
            end 
        Citizen.Wait(Timer)
    end
end)
  
function spawnCarTagJob(car)
    local car = GetHashKey(car)
  
    RequestModel(car)
    while not HasModelLoaded(car) do
        RequestModel(car)
        Citizen.Wait(0)
    end
  
    local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), false))
    local vehicle = CreateVehicle(car, tagjob.pos.spawnvoiture.position.x, tagjob.pos.spawnvoiture.position.y, tagjob.pos.spawnvoiture.position.z, tagjob.pos.spawnvoiture.position.h, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    local plaque = "tagjob"..math.random(1,9)
    SetVehicleNumberPlateText(vehicle, plaque) 
    SetPedIntoVehicle(GetPlayerPed(-1),vehicle,-1)
end



function tenueTagJob()
    TriggerEvent('skinchanger:getSkin', function(skin)
        local uniformObject
        if skin.sex == 0 then
            uniformObject = tagjob.Uniforms.male
        else
            uniformObject = tagjob.Uniforms.female
        end
        if uniformObject then
            TriggerEvent('skinchanger:loadClothes', skin, uniformObject)
        end
    end)
end


function vcivil()
    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
        TriggerEvent('skinchanger:loadSkin', skin)
       end)
    end

itemstock = {}
function VRetirerobjet()
    local StockTagJob = RageUI.CreateMenu("Coffre", "~p~T.A.G")
    StockTagJob:SetRectangleBanner(255, 0, 0)
    ESX.TriggerServerCallback('tagjob:getStockItems', function(items) 
    itemstock = items
    RageUI.Visible(StockTagJob, not RageUI.Visible(StockTagJob))
        while StockTagJob do
            Citizen.Wait(0)
                RageUI.IsVisible(StockTagJob, true, true, true, function()
                        for k,v in pairs(itemstock) do 
                            if v.count ~= 0 then
                            RageUI.ButtonWithStyle(v.label, nil, {RightLabel = v.count}, true, function(Hovered, Active, Selected)
                                if Selected then
                                    local count = KeyboardInput("Combien ?", '' , 8)
                                    TriggerServerEvent('tagjob:getStockItem', v.name, tonumber(count))
                                    VRetirerobjet()
                                end
                            end)
                        end
                    end
                end, function()
                end)
            if not RageUI.Visible(StockTagJob) then
            StockTagJob = RMenu:DeleteType("Coffre", true)
        end
    end
end)
end

local PlayersItem = {}
function VDeposerobjet()
    local DepositTagJob = RageUI.CreateMenu("Coffre", "~r~T.A.G's")
    DepositTagJob:SetRectangleBanner(255, 0, 0)
    ESX.TriggerServerCallback('tagjob:getPlayerInventory', function(inventory)
        RageUI.Visible(DepositTagJob, not RageUI.Visible(DepositTagJob))
    while DepositTagJob do
        Citizen.Wait(0)
            RageUI.IsVisible(DepositTagJob, true, true, true, function()
                for i=1, #inventory.items, 1 do
                    if inventory ~= nil then
                            local item = inventory.items[i]
                            if item.count > 0 then
                                        RageUI.ButtonWithStyle(item.label, nil, {RightLabel = item.count}, true, function(Hovered, Active, Selected)
                                            if Selected then
                                            local count = KeyboardInput("Combien ?", '' , 8)
                                            TriggerServerEvent('tagjob:putStockItems', item.name, tonumber(count))
                                            VDeposerobjet()
                                        end
                                    end)
                                end
                            else
                                RageUI.Separator('Chargement en cours')
                            end
                        end
                    end, function()
                    end)
                if not RageUI.Visible(DepositTagJob) then
                DepositTagJob = RMenu:DeleteType("Coffre", true)
            end
        end
    end)
end

RegisterNetEvent("aTagJob:envoielanotif")
AddEventHandler("aTagJob:envoielanotif", function()
    ESX.ShowAdvancedNotification("T.A.G", "~r~Contrat", "Un nouveau contrat a été ajouter! Ouvrez votre menu [F6]", "CHAR_ARTHUR", 8)
end)