
tagjob             = {}

tagjob.jeveuxmarker = true --- true = Oui | false = Non
tagjob.jeveuxblips = true --- true = Oui | false = Non
tagjob.jeveuxmarkercontratTag = false --- true = Oui | false = Non

--Position Job
tagjob.pos = {
	coffre = {
		position = {x = -697.11, y = 633.86, z = 155.18}
	},
	contratTag = {
		position = {x = -687.49, y = 665.36, z = 151.94}
	},
	garage = {
		position = {x = -709.71, y = 644.41, z = 155.18}
	},
	spawnvoiture = {
		position = {x = -708.5, y = 654.08, z = 154.18, h = 351.36}
	},
	boss = {
		position = {x = -717.7, y = 632.8, z = 159.19}
	},
	blips = {
		position = {x = -717.7, y = 632.8, z = 159.19}
	},
}

--Garage
tagjob.GTagJobvoiture = {
	{nom = "Burrito", modele = "burrito"},
}

--vestiaire 
tagjob.Uniforms = {
	male = {
		['bags_1'] = 0, ['bags_2'] = 0,
		['tshirt_1'] = 125, ['tshirt_2'] = 0,
		['torso_1'] = 214, ['torso_2'] = 9,
		['arms'] = 4,
		['pants_1'] = 34, ['pants_2'] = 0,
		['shoes_1'] = 12, ['shoes_2'] = 6,
	},
	female = {
		['bags_1'] = 0, ['bags_2'] = 0,
		['tshirt_1'] = 9,['tshirt_2'] = 0,
		['torso_1'] = 54, ['torso_2'] = 3,
		['arms'] = 14, ['arms_2'] = 0,
		['pants_1'] = 45, ['pants_2'] = 1,
		['shoes_1'] = 43, ['shoes_2'] = 1,
	}
}

--logs discord
tagjob.webhook = {
	onContratTag = "Mettre son lien webhook ici !!!"
}

-- selection ped aléatoire (Victime)
tagjob.pedMissionC = {
	[1] = "g_m_y_ballaorig_01",
	[2] = "s_m_y_xmech_02",
	[3] = "g_m_y_lost_03",
	[4] = "cs_karen_daniels",
	[5] = "a_f_y_beach_02",
	[6] = "a_m_o_tramp_01",
}

-- selection ped aléatoire (Agresseur)
tagjob.pedTAGMission = {
	[1] = "g_m_m_chicold_01",
	[2] = "s_m_y_marine_02",
	[3] = "mp_m_bogdangoon",
	[4] = "s_m_y_pestcont_01",
	[5] = "a_m_y_hiker_01",
	[6] = "s_m_y_doorman_01",
}


-- selection point spawn aléatoire
tagjob.pMission = {
	[1] = {x = -1172.78, y = -1735.63, z = 3.16},
	[2] = {x = 1419.06, y = 6583.59, z = 12.56},
	[3] = {x = 1666.37, y = 4771.55, z = 40.94},
	[4] = {x = 1690.82, y = 3871.31, z = 33.83},
	[5] = {x = 1431.32, y = 3682.19, z = 32.87},
	[6] = {x = -3230.72, y = 1079.15, z = 9.84}
}

-- selection niveau de mission aléatoire
tagjob.styleMission = {
	[3] = {label = "Mission Haut risque", item = "chequier"},
	[2] = {label = "Mission risque moyen", item = "chequelourd"},
	[1] = {label = "Mission risque faible", item = "cheque"}
}

--pos fin de mission
tagjob.posMissionFinal = {
	[1] = {x = 331.38, y = 2621.15, z = 43.49},
	[2] = {x = 257.21, y = -1638.73, z = 28.28},
	[3] = {x = -1950.34, y = -514.56, z = 10.86},
	[4] = {x = -604.69, y = 401.6, z = 100.33},
	[5] = {x = 971.92, y = -181.98, z = 71.84},
	[6] = {x = -433.02, y = 6206.12, z = 28.76}
}
