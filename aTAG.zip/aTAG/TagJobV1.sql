USE `es_extended`;

INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_tagjob', 'T.A.G', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_tagjob', 'T.A.G', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_tagjob', 'T.A.G', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('tagjob', 'T.A.G')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('tagjob',0,'recrue','Recrue',20,'{}','{}'),
	('tagjob',1,'agent','Agent',40,'{}','{}'),
	('tagjob',2,'pro','Pro',60,'{}','{}'),
	('tagjob',3,'boss','Boss',100,'{}','{}')
;

